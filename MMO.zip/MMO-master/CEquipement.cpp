/*#include <iostream>
#include "CEquipement.h"

#define EQUI nsEquipement::CEquipement

using namespace std;
using namespace nsEquipement;

EQUI::CEquipement (string itemName, unsigned itemLevel, unsigned evolutiveItemLevel, unsigned dropRate, unsigned RarityIndex) noexcept
    :m_ItemName (itemName), m_ItemLevel (itemLevel), m_EvolutiveItemLevel (evolutiveItemLevel), m_DropRate (dropRate), m_RarityIndex (RarityIndex) {}

void EQUI::display (void) noexcept {
    unsigned VSize = m_VItemName.size();
    for (unsigned i = 0; i < VSize; ++i) {

        cout    << "Nom de l'item : "                      << m_VItemName[i]  <<          endl
                << "Niveau minimum pour equiper l'item : " << m_VItemLevel[i] <<          endl
                << "Niveau de l'item : "                   << m_VEvolutiveItemLevel[i] << endl
                << "Taux de drop de l'item : "             << m_VDropRate[i] <<           endl
                << "Rarete de l'item : "                   << m_VRarityIndex[i] <<        endl ;
    }


}


*/
