#ifndef CGUILDE_H
#define CGUILDE_H

#include <string>
#include <iostream>
#include <vector>
#include "CPersonnage.h"
#include "Types.h"

namespace nsGuilde {

    class CGuilde {

        private:
            Str m_Name;
            unsigned m_Level;

        public:
            CGuilde (Str Name, unsigned Level = 1) noexcept;


#endif // CGUILDE_H
