#ifndef CPERSONAGE_H
#define CPERSONAGE_H

#include <string>
#include <iostream>
#include <vector>
#include "CEquipement.h"
#include "Types.h"

#define EQUI nsEquipement::CEquipement
#define GUIL nsGuilde::CGuilde

using namespace nsEquipement;

namespace nsPersonnage {

    class CPersonnage {

        private:
            Str m_Name;
            unsigned m_Level;
            VUns m_VLevelStuff;
            unsigned m_eLevel;
            VStr m_VStuff;

            /*GUIL::CGuilde * Guilde;
            EQUI::CEquipement * Equipement;*/
        public:
            CPersonnage (Str Name,
                         unsigned Level,
                         VUns VLevelStuff,
                         VStr VStuff) noexcept;

            void compairCharacters (CPersonnage & P1) noexcept;
            unsigned e_LevelCalculation (VUns VLevelStuff) noexcept;
            VStr getStuff() noexcept;
            Str getName() const noexcept;
            unsigned getLevel() const noexcept;
            unsigned get_eLevel() const noexcept;
            void createGuild(Str Name) noexcept;
    };

}

#endif // CPERSONAGE_H
