#include <iostream>
#include "CEquipement.h"
#include "CPersonnage.h"

#define EQUI nsEquipement::CEquipement
#define PERS nsPersonnage::CPersonnage

using namespace std;
using namespace nsEquipement;
using namespace nsPersonnage;

namespace  {

    void testCPersonnage () {
        vector <unsigned> VLevelStufKirito {430,427,428,436,433,430,427,428,436,433};
        vector <string> VStuffKirito {"Casque du Dragon",
                                      "Armure du Dragon",
                                      "Pantalon du Dragon",
                                      "Gant gauche du Dragon",
                                      "Gant droit du Dragon",
                                      "Botte gauche du Dragon",
                                      "Botte droite du Dragon",
                                      "Epée du Dragon",
                                      "Rapière de Glace",
                                      "Cape du Dragon"};

        vector <unsigned> VLevelStufDeathGun {330,127,128,136,133,130,127,128,136,133};
        vector <string> VStuffDeathGun {"Casque du Tueur",
                                        "Armure du Tueur",
                                        "Pantalon du Tueur",
                                        "Gant gauche du Tueur",
                                        "Gant droit du Tueur",
                                        "Botte gauche du Tueur",
                                        "Botte droite du Tueur",
                                        "Revolver du Tueur",
                                        "Sniper silencieux",
                                        "Cape du Tueur"};

        PERS P ("Kirito", 100, VLevelStufKirito, VStuffKirito);
        PERS P1 ("Death Gun", 50, VLevelStufDeathGun, VStuffDeathGun);
        P.compairCharacters(P1);
    }

    /*void testCEquipement () {
        vector <string> VItemName;
        vector <unsigned> VItemLevel, VEvolutiveItemLevel, VDropRate, VRarityIndex;

        CEquipement monEquipTest ();
        monEquipTest.display();

    }*/

}

int main()
{
    testCPersonnage();
    //testCEquipement();
    return 0;
}
