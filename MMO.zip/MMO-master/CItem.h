#ifndef CITEM_H
#define CITEM_H

#include <string>
#include <iostream>
#include <vector>
#include "CEquipement.h"
#include "Types.h"

namespace nsItem {

    class CItem {

        private:
            std::vector <std::string>   m_VItemName;
            std::vector <unsigned>      m_VItemLevel;
            std::vector <unsigned>      m_VEvolutiveItemLevel;
            std::vector <unsigned>      m_VDropRate;
            std::vector <unsigned>      m_VRarityIndex;

#endif // CITEM_H
