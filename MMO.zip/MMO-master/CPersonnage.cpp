#include <iostream>
#include <iomanip>
#include "CEquipement.h"
#include "CPersonnage.h"

#define EQUI nsEquipement::CEquipement
#define PERS nsPersonnage::CPersonnage


using namespace std;
using namespace nsEquipement;
using namespace nsPersonnage;

PERS::CPersonnage (string Name,
                   unsigned Level,
                   vector <unsigned> VLevelStuff,
                   vector <string> VStuff) noexcept
    :m_Name (Name), m_Level (Level), m_VLevelStuff (VLevelStuff), m_VStuff (VStuff)
{
    m_eLevel = e_LevelCalculation (VLevelStuff);
}

void PERS::compairCharacters(CPersonnage &P1) noexcept {
    cout << setw(22) << "Niveau : " << endl
         << m_Name << " : " << m_Level << "          "
         << P1.getName() << " : " << P1.getLevel() << endl << endl;
    cout << setw(23) << "e-Level : " << endl
         << m_Name << " : " << m_eLevel << "          "
         << P1.getName() << " : " << P1.get_eLevel() << endl << endl;
    for (unsigned i = 0; i < 10 ; ++i) {
        cout << setw(35) << "Stuff : " << endl
             << m_Name << " : " << m_VStuff[i] << "          "
             << P1.getName() << " : " << P1.getStuff()[i] << endl << endl;
    }

    /*vector <vector <string>> Mat (13, vector <string> (3));
    Mat =
    {{" ", m_Name, P1.getName()},
     {"Niveau", to_string(m_Level), P1.getLevel()},
     {"e-Level",m_eLevel, P1.get_eLevel()},
     {"Casque",m_VStuff[0], P1.getStuff()[0]},
     {"Armure",m_VStuff[1], P1.getStuff()[1]},
     {"Pantalon",m_VStuff[2], P1.getStuff()[2]},
     {"Main Gauche",m_VStuff[3], P1.getStuff()[3]},
     {"Main Droite",m_VStuff[4], P1.getStuff()[4]},
     {"Pied Gauche",m_VStuff[5], P1.getStuff()[5]},
     {"Pied Droit",m_VStuff[6], P1.getStuff()[6]},
     {"Cape",m_VStuff[7], P1.getStuff()[7]},
     {"Arme 1",m_VStuff[8], P1.getStuff()[8]},
     {"Arme 2",m_VStuff[9], P1.getStuff()[9]};

     for () {
         for () {
            cout << Mat [][];
         }
     }*/

}

string PERS::getName() const noexcept {
    return m_Name;
}

unsigned PERS::getLevel() const noexcept {
    return m_Level;
}

unsigned PERS::get_eLevel() const noexcept {
    return m_eLevel;
}

vector <string> PERS::getStuff() noexcept {
    return m_VStuff;
}

unsigned PERS::e_LevelCalculation (vector <unsigned> VLevelStuff) noexcept {
    unsigned e_Level = 0;
    unsigned VSize = VLevelStuff.size();
    for (unsigned i = 0; i < VSize; ++i) {
        e_Level += VLevelStuff[i];
    }
    e_Level = (e_Level / VSize);
    return e_Level;
}

