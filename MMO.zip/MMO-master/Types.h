#ifndef TYPES_H
#define TYPES_H

#include <string>
#include <iostream>
#include <vector>

typedef std::string Str;
typedef std::vector <Str> VStr;
typedef std::vector <unsigned> VUns;

#endif // TYPES_H
