#ifndef CEQUIPEMENT_H
#define CEQUIPEMENT_H

#include <string>
#include <iostream>
#include <vector>
#include "Types.h"

namespace nsEquipement {

    class CEquipement {

        private:
            std::string m_Head;
            std::string m_Chest;
            std::string m_Pants;
            std::string m_LeftHand;
            std::string m_RightHand;
            std::string m_LeftBoot;
            std::string m_RightBoot;
            std::string m_1stWeapon;
            std::string m_2ndWeapon;
            std::string m_Back;
        public:
            CEquipement () noexcept;

            void display (void) noexcept;
    };

}

#endif // CEQUIPEMENT_H

